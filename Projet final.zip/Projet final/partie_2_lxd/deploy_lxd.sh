PROJECT=$1
PORT=$2

if [ -z "$PROJECT" ] || [ -z "$PORT" ]; then
    echo "Usage: $0 projet port_http"
    exit 1
fi

# Créer réseau 
lxc network show lxnet >/dev/null 2>&1 || \
    lxc network create lxnet ipv4.address=10.50.50.1/24 ipv4.nat=true ipv6.address=none

# Lancer conteneurs
lxc launch images:ubuntu/22.04 ${PROJECT}-web -n lxnet
lxc launch images:ubuntu/22.04 ${PROJECT}-db -n lxnet

# Limitation ressources
lxc config set ${PROJECT}-web limits.memory 512MB
lxc config set ${PROJECT}-db limits.memory 1GB

# Volume partagé (./shared → /var/www/html)
mkdir -p ./shared
lxc config device add ${PROJECT}-web shared disk source=$(pwd)/shared path=/var/www/html

# Installer Apache
lxc exec ${PROJECT}-web -- bash -c "apt update && apt install -y apache2"

# Installer MariaDB
lxc exec ${PROJECT}-db -- bash -c "apt update && apt install -y mariadb-server"

# Sécurisation iptables : autoriser seulement ${PROJECT}-web à accéder à la DB
WEB_IP=$(lxc list ${PROJECT}-web -c 4 --format csv | cut -d' ' -f1)
lxc exec ${PROJECT}-db -- bash -c "apt install -y iptables && iptables -A INPUT -p tcp --dport 3306 -s ${WEB_IP} -j ACCEPT && iptables -A INPUT -p tcp --dport 3306 -j DROP"

echo "Infra LXD déployée : Web accessible sur http://localhost:${PORT}"
